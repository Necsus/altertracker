document.getElementById('step1').addEventListener('click', async () => {
  const token = prompt("Collez ici votre token Bearer depuis altertracker.com");
  if (token) {
    localStorage.setItem('altertracker_token', token);
    alert("Token sauvegardé !");
  }
});

document.getElementById('step2').addEventListener('click', async () => {
  const token = localStorage.getItem('altertracker_token');
  if (!token) {
    alert("Veuillez d'abord saisir un token via l'étape 1.");
    return;
  }

  try {
    // ⚠️ Adapter cette URL si besoin
    const res = await fetch('https://api.altered.gg/user/collection');
    const collection = await res.json();

    const postRes = await fetch('https://api.altertracker.com/import', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(collection)
    });

    if (!postRes.ok) throw new Error("Erreur lors de l'import.");

    const result = await postRes.json();
    document.getElementById('success').classList.remove('hidden');
    document.getElementById('collection-link').href = result.collectionUrl ?? 'https://altertracker.com/my-collection';

  } catch (err) {
    alert("Erreur pendant l'import : " + err.message);
  }
});